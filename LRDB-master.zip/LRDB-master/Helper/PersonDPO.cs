﻿using LR_DB.Model;
using LR_DB.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace LR_DB.Helper
{
    public class ItogDpo : INotifyPropertyChanged
    {
        public int Id_Itog { get; set; }

        private string _shopName;
        public string ShopName
        {
            get => _shopName;
            set => SetProperty(ref _shopName, value);
        }

        private string _productName;
        public string ProductName
        {
            get => _productName;
            set => SetProperty(ref _productName, value);
        }

        private double _price;
        public double Price
        {
            get => _price;
            set => SetProperty(ref _price, value);
        }

        private int _count;
        public int Count
        {
            get => _count;
            set => SetProperty(ref _count, value);
        }

        public ItogDpo() { }

        public ItogDpo(int id, string shopName, string productName, double price, int count)
        {
            Id_Itog = id;
            ShopName = shopName;
            ProductName = productName;
            Price = price;
            Count = count;
        }

        public ItogDpo ShallowCopy() => (ItogDpo)MemberwiseClone();

        public ItogDpo CopyFromItog(Itog itog)
        {
            var vmShop = new ShopViewModel();
            var vmProduct = new ProductViewModel();

            string shopName = vmShop.ListShop.FirstOrDefault(s => s.Id_Shop == itog.Id_Shop)?.Name_Shop ?? string.Empty;
            string productName = vmProduct.ListProduct.FirstOrDefault(p => p.Id_Product == itog.Id_Product)?.Name_Product ?? string.Empty;

            this.Id_Itog = itog.Id_Itog;
            this.ShopName = shopName;
            this.ProductName = productName;
            this.Price = itog.Price;
            this.Count = itog.Count;
            return this;
        }

        public static ItogDpo FromItog(Itog itog, ShopViewModel shopVM, ProductViewModel productVM)
        {
            var shopName = shopVM.ListShop.FirstOrDefault(s => s.Id_Shop == itog.Id_Shop)?.Name_Shop;
            var productName = productVM.ListProduct.FirstOrDefault(p => p.Id_Product == itog.Id_Product)?.Name_Product;

            if (shopName == null || productName == null)
                return null;

            return new ItogDpo
            {
                Id_Itog = itog.Id_Itog,
                ShopName = shopName,
                ProductName = productName,
                Price = itog.Price,
                Count = itog.Count
            };
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        protected bool SetProperty<T>(ref T storage, T value, [CallerMemberName] string propertyName = "")
        {
            if (Equals(storage, value)) return false;
            storage = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}
