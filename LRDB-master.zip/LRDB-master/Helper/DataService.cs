﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using LR_DB.Model;

namespace LR_DB.Helper
{
    public static class DataService
    {
        private static readonly string ShopPath = "shop.json";
        private static readonly string ProductPath = "product.json";
        private static readonly string ItogPath = "itog.json";

        public static void SaveShops(ObservableCollection<Shop> shops)
        {
            File.WriteAllText(ShopPath, JsonSerializer.Serialize(shops));
        }

        public static ObservableCollection<Shop> LoadShops()
        {
            if (!File.Exists(ShopPath))
                return new ObservableCollection<Shop>();
            return JsonSerializer.Deserialize<ObservableCollection<Shop>>(File.ReadAllText(ShopPath));
        }

        public static void SaveProducts(ObservableCollection<Product> products)
        {
            File.WriteAllText(ProductPath, JsonSerializer.Serialize(products));
        }

        public static ObservableCollection<Product> LoadProducts()
        {
            if (!File.Exists(ProductPath))
                return new ObservableCollection<Product>();
            return JsonSerializer.Deserialize<ObservableCollection<Product>>(File.ReadAllText(ProductPath));
        }

        public static void SaveItogs(ObservableCollection<Itog> itogs)
        {
            File.WriteAllText(ItogPath, JsonSerializer.Serialize(itogs));
        }

        public static ObservableCollection<Itog> LoadItogs()
        {
            if (!File.Exists(ItogPath))
                return new ObservableCollection<Itog>();
            return JsonSerializer.Deserialize<ObservableCollection<Itog>>(File.ReadAllText(ItogPath));
        }

        // Если нужно загружать/сохранять из произвольного файла
        public static void SaveShopsToFile(ObservableCollection<Shop> shops, string path)
            => File.WriteAllText(path, JsonSerializer.Serialize(shops));

        public static ObservableCollection<Shop> LoadShopsFromFile(string path)
        {
            if (!File.Exists(path))
                return new ObservableCollection<Shop>();
            return JsonSerializer.Deserialize<ObservableCollection<Shop>>(File.ReadAllText(path));
        }

        public static void SaveProductsToFile(ObservableCollection<Product> products, string path)
            => File.WriteAllText(path, JsonSerializer.Serialize(products));

        public static ObservableCollection<Product> LoadProductsFromFile(string path)
        {
            if (!File.Exists(path))
                return new ObservableCollection<Product>();
            return JsonSerializer.Deserialize<ObservableCollection<Product>>(File.ReadAllText(path));
        }

        public static void SaveItogsToFile(ObservableCollection<Itog> itogs, string path)
            => File.WriteAllText(path, JsonSerializer.Serialize(itogs));

        public static ObservableCollection<Itog> LoadItogsFromFile(string path)
        {
            if (!File.Exists(path))
                return new ObservableCollection<Itog>();
            return JsonSerializer.Deserialize<ObservableCollection<Itog>>(File.ReadAllText(path));
        }
    }
}