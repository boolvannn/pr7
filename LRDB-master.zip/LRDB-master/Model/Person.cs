﻿using LR_DB.Helper;
using LR_DB.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR_DB.Model
{
    public class Shop
    {
        public int Id_Shop { get; set; }
        public string Name_Shop { get; set; }
    }

    public class Product
    {
        public int Id_Product { get; set; }
        public string Name_Product { get; set; }
    }

    public class Itog
    {
        public int Id_Itog { get; set; }
        public int Id_Product { get; set; }
        public int Id_Shop { get; set; }
        public double Price { get; set; }
        public int Count { get; set; }

        // Копирование из DPO (например, если нужен отображаемый класс)
        public Itog CopyFromItogDpo(ItogDpo itogDpo)
        {
            var vmShop = new ShopViewModel();
            var vmProduct = new ProductViewModel();

            int shopId = vmShop.ListShop.FirstOrDefault(s => s.Name_Shop == itogDpo.ShopName)?.Id_Shop ?? 0;
            int productId = vmProduct.ListProduct.FirstOrDefault(p => p.Name_Product == itogDpo.ProductName)?.Id_Product ?? 0;

            this.Id_Itog = itogDpo.Id_Itog;
            this.Id_Shop = shopId;
            this.Id_Product = productId;
            this.Price = itogDpo.Price;
            this.Count = itogDpo.Count;
            return this;
        }

        internal Itog ShallowCopy()
        {
            throw new NotImplementedException();
        }
    }
}



