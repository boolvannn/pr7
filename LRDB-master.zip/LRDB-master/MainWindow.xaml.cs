﻿using System.Windows;
using LR_DB.View;

namespace LR_DB
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Открытие окна управления магазинами
        //private void Shop_OnClick(object sender, RoutedEventArgs e)
        //{
        //    // Предполагаем, что класс WindowShop уже есть в проекте
        //    var wShop = new WindowShop();
        //    wShop.Show();
        //}

        // Открытие окна управления продуктами
        private void Product_OnClick(object sender, RoutedEventArgs e)
        {
            var wProduct = new WindowProduct();
            wProduct.Show();
        }

        // Открытие окна управления итогами
        private void Itog_OnClick(object sender, RoutedEventArgs e)
        {
            var wItog = new WindowItog();
            wItog.Show();
        }

        private void Shop_OnClick(object sender, RoutedEventArgs e)
        {

        }
    }
}
