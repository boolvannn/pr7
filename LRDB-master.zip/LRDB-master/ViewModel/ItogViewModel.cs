﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using LR_DB.Helper;
using LR_DB.Model;
using LR_DB.View;

namespace LR_DB.ViewModel
{
    public class ItogViewModel : INotifyPropertyChanged
    {
        private Itog selectedItog;
        public Itog SelectedItog
        {
            get => selectedItog;
            set
            {
                selectedItog = value;
                OnPropertyChanged();
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public ObservableCollection<Itog> ListItog { get; set; }
        public ICommand EditItog { get; }
        public ICommand AddItog { get; }

        public ItogViewModel()
        {
            ListItog = DataService.LoadItogs();
            EditItog = new RelayCommand(ExecuteEditItog, CanExecuteEditItog);
            AddItog = new RelayCommand(ExecuteAddItog);
        }

        private void ExecuteEditItog(object parameter)
        {
            if (SelectedItog == null) return;

            Itog temp = SelectedItog.ShallowCopy(); // Предположим, вы реализуете ShallowCopy
            var itogDpo = new ItogDpo().CopyFromItog(temp);

            var window = new WindowNewItog
            {
                Title = "Редактирование итога",
                Owner = Application.Current.MainWindow,
                DataContext = itogDpo
            };

            if (window.ShowDialog() == true)
            {
                // Сохранить изменения в сущности Itog
                SelectedItog.Id_Shop = temp.Id_Shop;
                SelectedItog.Id_Product = temp.Id_Product;
                SelectedItog.Price = temp.Price;
                SelectedItog.Count = temp.Count;

                DataService.SaveItogs(ListItog);
                OnPropertyChanged(nameof(ListItog));
            }
        }

        private void ExecuteAddItog(object parameter)
        {
            var newItog = new Itog
            {
                Id_Itog = MaxId() + 1,
                Id_Product = 0, // Или какое-то значение по умолчанию
                Id_Shop = 0,
                Price = 0,
                Count = 0
            };

            var itogDpo = new ItogDpo().CopyFromItog(newItog);
            var window = new WindowNewItog
            {
                Title = "Новый итог",
                Owner = Application.Current.MainWindow,
                DataContext = itogDpo
            };

            if (window.ShowDialog() == true)
            {
                ListItog.Add(newItog);
                DataService.SaveItogs(ListItog);
                OnPropertyChanged(nameof(ListItog));
            }
        }

        private bool CanExecuteEditItog(object parameter)
        {
            return SelectedItog != null;
        }

        public int MaxId()
        {
            if (ListItog.Count == 0)
                return 0;
            return ListItog.Max(i => i.Id_Itog);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
