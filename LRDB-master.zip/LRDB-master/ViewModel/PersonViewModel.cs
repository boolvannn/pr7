﻿using LR_DB.View;
using LR_DB.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LR_DB.Helper;

namespace LR_DB.ViewModel
{
    public class ShopViewModel
    {
        public ObservableCollection<Shop> ListShop { get; set; } =
            new ObservableCollection<Shop>();

        public ShopViewModel()
        {
            ListShop = DataService.LoadShops();
        }

        public int MaxId()
        {
            int max = 0;
            foreach (var s in this.ListShop)
            {
                if (max < s.Id_Shop)
                {
                    max = s.Id_Shop;
                }
            }
            return max;
        }

        public Shop FindShop(int id)
        {
            return ListShop.FirstOrDefault(s => s.Id_Shop == id);
        }
    }
}
