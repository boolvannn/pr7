﻿using LR_DB.Model;
using LR_DB.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using LR_DB.Helper;
namespace LR_DB.ViewModel
{
    public class ProductViewModel
    {
        public ObservableCollection<Product> ListProduct { get; set; } =
            new ObservableCollection<Product>();

        public ProductViewModel()
        {
            ListProduct = DataService.LoadProducts();
        }

        public int MaxId()
        {
            int max = 0;
            foreach (var p in this.ListProduct)
            {
                if (max < p.Id_Product)
                {
                    max = p.Id_Product;
                }
            }
            return max;
        }

        public Product FindProduct(int id)
        {
            return ListProduct.FirstOrDefault(p => p.Id_Product == id);
        }
    }
}