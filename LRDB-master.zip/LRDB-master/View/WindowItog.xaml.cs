﻿using LR_DB.Helper;
using LR_DB.Model;
using LR_DB.View.LR_DB.Helper;
using LR_DB.ViewModel;
using Microsoft.Win32;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace LR_DB.View
{
    /// <summary>
    /// Логика взаимодействия для WindowItog.xaml
    /// </summary>
    public partial class WindowItog : Window
    {
        private ItogViewModel vmItog;
        private ShopViewModel vmShop;
        private ProductViewModel vmProduct;

        // Для отображения в ListView: коллекция DPO (с именами магазинов/продуктов)
        private ObservableCollection<ItogDpo> itogsDPO;

        // Списки магазинов и продуктов для ComboBox’ов
        private List<Shop> shops;
        private List<Product> products;

        public WindowItog()
        {
            InitializeComponent();

            vmItog = new ItogViewModel();
            vmShop = new ShopViewModel();
            vmProduct = new ProductViewModel();

            shops = vmShop.ListShop.ToList();
            products = vmProduct.ListProduct.ToList();

            itogsDPO = new ObservableCollection<ItogDpo>();
            foreach (var itog in vmItog.ListItog)
            {
                var dpo = new ItogDpo();
                dpo.CopyFromItog(itog);
                itogsDPO.Add(dpo);
            }

            lvItog.ItemsSource = itogsDPO;

            // При закрытии окна сохраняем JSON-файлы
            this.Closed += (s, e) =>
            {
                DataService.SaveItogs(vmItog.ListItog);
                DataService.SaveShops(vmShop.ListShop);
                DataService.SaveProducts(vmProduct.ListProduct);
            };
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // Окно для ввода нового Itog
            var win = new WindowNewItog
            {
                Title = "Новый итог",
                Owner = this
            };

            // Формируем новый DPO с новым Id и пустым именем продукта
            int nextId = vmItog.MaxId() + 1;
            var newDpo = new ItogDpo
            {
                Id_Itog = nextId,
                ShopName = shops.FirstOrDefault()?.Name_Shop ?? string.Empty,
                ProductName = string.Empty,
                Price = 0,
                Count = 0
            };

            win.DataContext = newDpo;
            win.CbShop.ItemsSource = shops;
            win.CbShop.SelectedItem = shops.FirstOrDefault();

            if (win.ShowDialog() == true)
            {
                // Проверяем, что магазин выбран
                var selectedShop = win.CbShop.SelectedItem as Shop;
                if (selectedShop == null)
                {
                    MessageBox.Show("Выберите магазин!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Проверяем, что введено название продукта
                if (string.IsNullOrWhiteSpace(newDpo.ProductName))
                {
                    MessageBox.Show("Введите название продукта!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Проверка на отрицательные значения
                if (newDpo.Price < 0)
                {
                    MessageBox.Show("Цена не может быть отрицательной!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (newDpo.Count < 0)
                {
                    MessageBox.Show("Количество не может быть отрицательным!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Сохраняем DPO и модельную запись
                newDpo.ShopName = selectedShop.Name_Shop;
                itogsDPO.Add(newDpo);

                var newItog = new Itog();
                newItog.CopyFromItogDpo(newDpo);
                vmItog.ListItog.Add(newItog);
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedDpo = lvItog.SelectedItem as ItogDpo;
            if (selectedDpo == null)
            {
                MessageBox.Show("Необходимо выбрать запись для редактирования", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Временная копия для редактирования
            var tempDpo = selectedDpo.ShallowCopy();

            var win = new WindowNewItog
            {
                Title = "Редактирование итога",
                Owner = this,
                DataContext = tempDpo
            };
            win.CbShop.ItemsSource = shops;
            // Устанавливаем текущее значение магазина
            win.CbShop.Text = tempDpo.ShopName;

            if (win.ShowDialog() == true)
            {
                var selShop = win.CbShop.SelectedItem as Shop;
                if (selShop == null)
                {
                    MessageBox.Show("Выберите магазин!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Проверяем, что введено название продукта
                if (string.IsNullOrWhiteSpace(tempDpo.ProductName))
                {
                    MessageBox.Show("Введите название продукта!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (tempDpo.Price < 0)
                {
                    MessageBox.Show("Цена не может быть отрицательной!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (tempDpo.Count < 0)
                {
                    MessageBox.Show("Количество не может быть отрицательным!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Обновляем выбранный DPO
                selectedDpo.ShopName = selShop.Name_Shop;
                selectedDpo.ProductName = tempDpo.ProductName;
                selectedDpo.Price = tempDpo.Price;
                selectedDpo.Count = tempDpo.Count;

                // Обновляем ListView
                lvItog.ItemsSource = null;
                lvItog.ItemsSource = itogsDPO;

                // Обновляем модельную запись
                var finder = new FindItog(selectedDpo.Id_Itog);
                var modelItog = vmItog.ListItog.FirstOrDefault(i => finder.ItogPredicate(i));
                if (modelItog != null)
                {
                    modelItog.CopyFromItogDpo(selectedDpo);
                }
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selectedDpo = lvItog.SelectedItem as ItogDpo;
            if (selectedDpo == null)
            {
                MessageBox.Show("Необходимо выбрать запись для удаления", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var result = MessageBox.Show(
                $"Удалить запись итога (ID: {selectedDpo.Id_Itog})?\nМагазин: {selectedDpo.ShopName}, Продукт: {selectedDpo.ProductName}",
                "Подтвердите удаление",
                MessageBoxButton.OKCancel,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.OK)
            {
                itogsDPO.Remove(selectedDpo);

                var finder = new FindItog(selectedDpo.Id_Itog);
                var modelItog = vmItog.ListItog.FirstOrDefault(i => finder.ItogPredicate(i));
                if (modelItog != null)
                {
                    vmItog.ListItog.Remove(modelItog);
                }
            }
        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Filter = "JSON файлы (*.json)|*.json",
                Title = "Загрузить итоги из JSON"
            };

            if (dlg.ShowDialog() == true)
            {
                var loaded = DataService.LoadItogsFromFile(dlg.FileName);
                itogsDPO.Clear();

                foreach (var itog in loaded)
                {
                    var dpo = new ItogDpo();
                    dpo.CopyFromItog(itog);
                    itogsDPO.Add(dpo);
                }

                vmItog.ListItog = loaded;

                lvItog.ItemsSource = null;
                lvItog.ItemsSource = itogsDPO;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog
            {
                Filter = "JSON файлы (*.json)|*.json",
                Title = "Сохранить итоги в файл"
            };

            if (dlg.ShowDialog() == true)
            {
                DataService.SaveItogsToFile(vmItog.ListItog, dlg.FileName);
            }
        }
    }

    // Predicate-класс для поиска Itog по Id_Itog (аналог FindPerson)
    namespace LR_DB.Helper
    {
        public class FindItog
        {
            private int id;
            public FindItog(int id) => this.id = id;
            public bool ItogPredicate(Itog itog) => itog.Id_Itog == id;
        }
    }
}
