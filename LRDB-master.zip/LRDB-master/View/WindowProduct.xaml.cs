﻿using LR_DB.Helper;
using LR_DB.Model;
using LR_DB.ViewModel;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace LR_DB.View
{
    /// <summary>
    /// Логика взаимодействия для WindowProduct.xaml
    /// </summary>
    public partial class WindowProduct : Window
    {
        private ProductViewModel vmProduct;

        public WindowProduct()
        {
            InitializeComponent();
            vmProduct = DataContext as ProductViewModel;

            // При закрытии сохраняем список продуктов
            this.Closed += (s, e) =>
            {
                DataService.SaveProducts(vmProduct.ListProduct);
            };
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // Окно для ввода нового продукта
            var win = new WindowNewProduct
            {
                Title = "Новый продукт",
                Owner = this
            };

            // Создаем новый экземпляр Product с новым Id
            int nextId = vmProduct.MaxId() + 1;
            var newProduct = new Product
            {
                Id_Product = nextId,
                Name_Product = string.Empty
            };

            win.DataContext = newProduct;

            if (win.ShowDialog() == true)
            {
                // Проверяем, что введено название
                if (string.IsNullOrWhiteSpace(newProduct.Name_Product))
                {
                    MessageBox.Show("Введите название продукта.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                vmProduct.ListProduct.Add(newProduct);
                DataService.SaveProducts(vmProduct.ListProduct);
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selected = lvProduct.SelectedItem as Product;
            if (selected == null)
            {
                MessageBox.Show("Выберите продукт для редактирования.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Временная копия для редактирования
            var temp = new Product
            {
                Id_Product = selected.Id_Product,
                Name_Product = selected.Name_Product
            };

            var win = new WindowNewProduct
            {
                Title = "Редактирование продукта",
                Owner = this,
                DataContext = temp
            };

            if (win.ShowDialog() == true)
            {
                // Проверяем, что введено название
                if (string.IsNullOrWhiteSpace(temp.Name_Product))
                {
                    MessageBox.Show("Введите название продукта.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Сохраняем изменение
                selected.Name_Product = temp.Name_Product;

                // Обновляем ListView (сброс ItemsSource, чтобы отображение обновилось)
                lvProduct.ItemsSource = null;
                lvProduct.ItemsSource = vmProduct.ListProduct;
                DataService.SaveProducts(vmProduct.ListProduct);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = lvProduct.SelectedItem as Product;
            if (selected == null)
            {
                MessageBox.Show("Выберите продукт для удаления.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var result = MessageBox.Show($"Удалить продукт: {selected.Name_Product}?", "Подтвердите удаление", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
            if (result == MessageBoxResult.OK)
            {
                vmProduct.ListProduct.Remove(selected);
                DataService.SaveProducts(vmProduct.ListProduct);
            }
        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Filter = "JSON файлы (*.json)|*.json",
                Title = "Загрузить продукты из JSON"
            };
            if (dlg.ShowDialog() == true)
            {
                var loaded = DataService.LoadProductsFromFile(dlg.FileName);
                vmProduct.ListProduct = loaded;

                lvProduct.ItemsSource = null;
                lvProduct.ItemsSource = vmProduct.ListProduct;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog
            {
                Filter = "JSON файлы (*.json)|*.json",
                Title = "Сохранить продукты в файл"
            };
            if (dlg.ShowDialog() == true)
            {
                DataService.SaveProductsToFile(vmProduct.ListProduct, dlg.FileName);
            }
        }
    }
}
