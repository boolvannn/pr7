﻿using System.Windows;

namespace LR_DB.View
{
    /// <summary>
    /// Логика взаимодействия для WindowNewProduct.xaml
    /// </summary>
    public partial class WindowNewProduct : Window
    {
        public WindowNewProduct()
        {
            InitializeComponent();
        }

        private void BtSave_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, что название не пустое
            if (string.IsNullOrWhiteSpace(TbName.Text))
            {
                MessageBox.Show("Введите название продукта.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
        }
    }
}
