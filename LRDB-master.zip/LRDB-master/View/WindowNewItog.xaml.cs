﻿using LR_DB.Model;
using System.Windows;

namespace LR_DB.View
{
    /// <summary>
    /// Логика взаимодействия для WindowNewItog.xaml
    /// </summary>
    public partial class WindowNewItog : Window
    {
        public WindowNewItog()
        {
            InitializeComponent();
        }

        private void BtSave_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, что магазин выбран
            if (CbShop.SelectedItem == null)
            {
                MessageBox.Show("Выберите магазин.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проверяем, что введено название продукта
            if (string.IsNullOrWhiteSpace(TbProduct.Text))
            {
                MessageBox.Show("Введите название продукта.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проверяем цену
            if (!double.TryParse(TbPrice.Text, out double price) || price < 0)
            {
                MessageBox.Show("Введите корректную цену (неотрицательное число).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проверяем количество
            if (!int.TryParse(TbCount.Text, out int count) || count < 0)
            {
                MessageBox.Show("Введите корректное количество (целое неотрицательное).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Если все проверки пройдены — возвращаем DialogResult = true
            DialogResult = true;
        }
    }
}
