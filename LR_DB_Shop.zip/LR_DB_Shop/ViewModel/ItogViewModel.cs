﻿using LR_DB_Shop.Model;
using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;

namespace LR_DB_Shop.ViewModel
{
    public class ItogViewModel : INotifyPropertyChanged
    {
        private const string ItogsPath = "Data/itog.json";
        private const string ShopsPath = "Data/shop.json";
        private const string ProductsPath = "Data/product.json";

        public ObservableCollection<Itog> ListItog { get; set; } = new ObservableCollection<Itog>();
        public ObservableCollection<Shop> ListShop { get; set; } = new ObservableCollection<Shop>();
        public ObservableCollection<Product> ListProduct { get; set; } = new ObservableCollection<Product>();

        public ItogViewModel()
        {
            EnsureDataDirectoryExists();
        }

        private void EnsureDataDirectoryExists()
        {
            if (!Directory.Exists("Data"))
            {
                Directory.CreateDirectory("Data");
            }
        }

        public void LoadItogs()
        {
            try
            {
                if (File.Exists(ItogsPath))
                {
                    var json = File.ReadAllText(ItogsPath);
                    var itogs = JsonConvert.DeserializeObject<Itog[]>(json) ?? Array.Empty<Itog>();
                    ListItog = new ObservableCollection<Itog>(itogs);
                    OnPropertyChanged(nameof(ListItog));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки итога: {ex.Message}");
            }
        }

        public void LoadShops()
        {
            try
            {
                if (File.Exists(ShopsPath))
                {
                    var json = File.ReadAllText(ShopsPath);
                    var shops = JsonConvert.DeserializeObject<Shop[]>(json) ?? Array.Empty<Shop>();
                    ListShop = new ObservableCollection<Shop>(shops);
                    OnPropertyChanged(nameof(ListShop));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки магазинов: {ex.Message}");
            }
        }

        public void LoadProducts()
        {
            try
            {
                if (File.Exists(ProductsPath))
                {
                    var json = File.ReadAllText(ProductsPath);
                    var products = JsonConvert.DeserializeObject<Product[]>(json) ?? Array.Empty<Product>();
                    ListProduct = new ObservableCollection<Product>(products);
                    OnPropertyChanged(nameof(ListProduct));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки продуктов: {ex.Message}");
            }
        }

        public void SaveItogs()
        {
            try
            {
                var json = JsonConvert.SerializeObject(ListItog, Formatting.Indented);
                File.WriteAllText(ItogsPath, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения итогов: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void AddItog(Itog itog)
        {
            ListItog.Add(itog);
            SaveItogs();
        }

        public void UpdateItog(Itog itog)
        {
            var existing = ListItog.FirstOrDefault(p => p.Id == itog.Id);
            if (existing != null)
            {
                existing.Price = itog.Price;
                existing.Count = itog.Count;
                existing.ShopId = itog.ShopId;
                existing.ProductId = itog.ProductId;
                SaveItogs();
            }
        }

        public void RemoveItog(int id)
        {
            var itog = ListItog.FirstOrDefault(p => p.Id == id);
            if (itog != null)
            {
                ListItog.Remove(itog);
                SaveItogs();
            }
        }

        public int GetMaxId() => ListItog.Any() ? ListItog.Max(p => p.Id) : 0;

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
