﻿using LR_DB_Shop.Helper;
using LR_DB_Shop.Model;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace LR_DB_Shop.ViewModel
{
    public class ProductViewModel : INotifyPropertyChanged
    {
        private const string ProductsPath = "Data/product.json";
        private Product _selectedProduct;
        public ObservableCollection<Product> ListProduct { get; set; } = new ObservableCollection<Product>();
        public string Error { get; set; }

        public Product SelectedProduct
        {
            get => _selectedProduct;
            set
            {
                _selectedProduct = value;
                OnPropertyChanged();
            }
        }

        public ProductViewModel()
        {
            EnsureDataDirectoryExists();
            LoadProducts();
        }

        private void EnsureDataDirectoryExists()
        {
            var dir = Path.GetDirectoryName(ProductsPath);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
        }

        public void LoadProducts()
        {
            try
            {
                if (File.Exists(ProductsPath))
                {
                    var json = File.ReadAllText(ProductsPath);
                    var products = JsonConvert.DeserializeObject<Product[]>(json) ?? Array.Empty<Product>();
                    ListProduct = new ObservableCollection<Product>(products);
                    OnPropertyChanged(nameof(ListProduct));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки продуктов: {ex.Message}");
            }
        }

        private void SaveProducts()
        {
            try
            {
                var json = JsonConvert.SerializeObject(ListProduct, Formatting.Indented);
                File.WriteAllText(ProductsPath, json);
            }
            catch (IOException ex)
            {
                Error = $"Ошибка сохранения: {ex.Message}";
                MessageBox.Show(Error, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int GetNextId()
        {
            return ListProduct.Count > 0 ? ListProduct.Max(r => r.Id) + 1 : 1;
        }

        public ICommand AddProductCommand => new RelayCommand(_ =>
        {
            var newProduct = new Product { Id = GetNextId() };
            var dialog = new WindowNewProduct
            {
                Title = "Новый продукт",
                DataContext = newProduct
            };

            if (dialog.ShowDialog() == true)
            {
                ListProduct.Add(newProduct);
                SelectedProduct = newProduct;
                SaveProducts();
            }
        });

        public ICommand EditProductCommand => new RelayCommand(_ =>
        {
            if (SelectedProduct == null) return;

            var productCopy = SelectedProduct.ShallowCopy();
            var dialog = new WindowNewProduct
            {
                Title = "Редактирование продукта",
                DataContext = productCopy
            };

            if (dialog.ShowDialog() == true)
            {
                SelectedProduct.NameProduct = productCopy.NameProduct;
                SaveProducts();
            }
        }, _ => SelectedProduct != null);

        public ICommand DeleteProductCommand => new RelayCommand(_ =>
        {
            if (SelectedProduct == null) return;

            var result = MessageBox.Show(
                $"Удалить продукт '{SelectedProduct.NameProduct}'?",
                "Подтверждение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                ListProduct.Remove(SelectedProduct);
                SelectedProduct = null;
                SaveProducts();
            }
        }, _ => SelectedProduct != null);

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
