﻿using LR_DB_Shop.Helper;
using LR_DB_Shop.Model;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace LR_DB_Shop.ViewModel
{
    public class ShopViewModel : INotifyPropertyChanged
    {
        private const string ShopsPath = "Data/shop.json";
        private Shop _selectedShop;
        public ObservableCollection<Shop> ListShop { get; set; } = new ObservableCollection<Shop>();
        public string Error { get; set; }

        public Shop SelectedShop
        {
            get => _selectedShop;
            set
            {
                _selectedShop = value;
                OnPropertyChanged();
            }
        }

        public ShopViewModel()
        {
            EnsureDataDirectoryExists();
            LoadShops();
        }

        private void EnsureDataDirectoryExists()
        {
            var dir = Path.GetDirectoryName(ShopsPath);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
        }

        public void LoadShops()
        {
            try
            {
                if (File.Exists(ShopsPath))
                {
                    var json = File.ReadAllText(ShopsPath);
                    var shops = JsonConvert.DeserializeObject<Shop[]>(json) ?? Array.Empty<Shop>();
                    ListShop = new ObservableCollection<Shop>(shops);
                    OnPropertyChanged(nameof(ListShop));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки магазинов: {ex.Message}");
            }
        }

        private void SaveShops()
        {
            try
            {
                var json = JsonConvert.SerializeObject(ListShop, Formatting.Indented);
                File.WriteAllText(ShopsPath, json);
            }
            catch (IOException ex)
            {
                Error = $"Ошибка сохранения: {ex.Message}";
                MessageBox.Show(Error, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int GetNextId()
        {
            return ListShop.Count > 0 ? ListShop.Max(r => r.Id) + 1 : 1;
        }

        public ICommand AddShopCommand => new RelayCommand(_ =>
        {
            var newShop = new Shop { Id = GetNextId() };
            var dialog = new WindowNewShop
            {
                Title = "Новый магазин",
                DataContext = newShop
            };

            if (dialog.ShowDialog() == true)
            {
                ListShop.Add(newShop);
                SelectedShop = newShop;
                SaveShops();
            }
        });

        public ICommand EditShopCommand => new RelayCommand(_ =>
        {
            if (SelectedShop == null) return;

            var shopCopy = SelectedShop.ShallowCopy();
            var dialog = new WindowNewShop
            {
                Title = "Редактирование магазино",
                DataContext = shopCopy
            };

            if (dialog.ShowDialog() == true)
            {
                SelectedShop.NameShop = shopCopy.NameShop;
                SaveShops();
            }
        }, _ => SelectedShop != null);

        public ICommand DeleteShopCommand => new RelayCommand(_ =>
        {
            if (SelectedShop == null) return;

            var result = MessageBox.Show(
                $"Удалить магазино '{SelectedShop.NameShop}'?",
                "Подтверждение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                ListShop.Remove(SelectedShop);
                SelectedShop = null;
                SaveShops();
            }
        }, _ => SelectedShop != null);

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

