﻿using System.ComponentModel;
using System.Data;
using System.Runtime.CompilerServices;

namespace LR_DB_Shop.Model
{
    public class Product : INotifyPropertyChanged
    {
        public int Id { get; set; }

        private string _nameProduct;
        public string NameProduct
        {
            get => _nameProduct;
            set
            {
                _nameProduct = value;
                OnPropertyChanged();
            }
        }

        public Product() { }
        public Product(int id, string nameProduct)
        {
            Id = id;
            NameProduct = nameProduct;
        }

        public Product ShallowCopy()
        {
            return (Product)this.MemberwiseClone();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
