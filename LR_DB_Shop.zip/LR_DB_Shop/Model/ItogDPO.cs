﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows;

namespace LR_DB_Shop.Model
{
    public class ItogDpo : INotifyPropertyChanged
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int ShopId { get; set; }

        private string _productName;
        public string ProductName
        {
            get => _productName;
            set
            {
                _productName = value;
                OnPropertyChanged();
            }
        }

        private string _shopName;
        public string ShopName
        {
            get => _shopName;
            set
            {
                _shopName = value;
                OnPropertyChanged();
            }
        }
        private string _priceText;
        public string PriceText
        {
            get => _priceText;
            set
            {
                if (decimal.TryParse(value, out decimal result) && result > 0)
                {
                    _priceText = value;
                    Price = result; 
                }
                else
                {
                    _priceText = value; 
                    MessageBox.Show("Цена должна быть положительным числом.");
                }
                OnPropertyChanged(); 
            }
        }

        private decimal _price;
        public decimal Price
        {
            get => _price;
            set
            {
                if (_price != value)
                {
                    _price = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(PriceFormatted));
                }
            }
        }

        public string PriceFormatted => _price.ToString("C", CultureInfo.CurrentCulture);

        private string _countText;
        public string CountText
        {
            get => _countText;
            set
            {
                if (int.TryParse(value, out int result) && result > 0)
                {
                    _countText = value;
                    _count = result;
                    OnPropertyChanged();
                }
                else
                {
                    MessageBox.Show("Количество должно быть положительным числом.");
                }
            }
        }

        private int _count;
        public int Count
        {
            get => _count;
            set
            {
                if (value > 0)
                {
                    _count = value;
                    OnPropertyChanged();
                }
                else
                {
                    MessageBox.Show("Количество должно быть положительным числом.");
                }
            }
        }


        public ItogDpo CopyFromItog(Itog itog)
        {
            this.Id = itog.Id;
            this.ProductId = itog.ProductId;
            this.ShopId = itog.ShopId;
            this.Price = itog.Price;
            this.Count = itog.Count;


            return this;
        }

        public ItogDpo CopyFromItogDpo(ItogDpo source)
        {
            this.Id = source.Id;
            this.ProductId = source.ProductId;
            this.ProductName = source.ProductName;
            this.ShopId = source.ShopId;
            this.ShopName = source.ShopName;
            this.Price = source.Price;
            this.Count = source.Count;
            return this;
        }

        public ItogDpo ShallowCopy()
        {
            return (ItogDpo)this.MemberwiseClone();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

