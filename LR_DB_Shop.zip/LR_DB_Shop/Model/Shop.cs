﻿using System.ComponentModel;
using System.Data;
using System.Runtime.CompilerServices;

namespace LR_DB_Shop.Model
{
    public class Shop : INotifyPropertyChanged
    {
        public int Id { get; set; }

        private string _nameShop;
        public string NameShop
        {
            get => _nameShop;
            set
            {
                _nameShop = value;
                OnPropertyChanged();
            }
        }

        public Shop() { }
        public Shop(int id, string nameShop)
        {
            Id = id;
            NameShop = nameShop;
        }

        public Shop ShallowCopy()
        {
            return (Shop)this.MemberwiseClone();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
