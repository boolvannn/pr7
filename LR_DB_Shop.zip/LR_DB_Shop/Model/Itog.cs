﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;

namespace LR_DB_Shop.Model
{
    public class Itog : INotifyPropertyChanged
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int ShopId { get; set; }

        private decimal _price;
        public decimal Price
        {
            get => _price;
            set
            {
                _price = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(PriceFormatted));
            }
        }

        private int _count;
        public int Count
        {
            get => _count;
            set
            {
                _count = value;
                OnPropertyChanged();
            }
        }


        public Itog CopyFromItogDpo(ItogDpo dpo)
        {
            Id = dpo.Id;
            ProductId = dpo.ProductId;
            ShopId = dpo.ShopId;
            Price = dpo.Price;
            Count = dpo.Count; 
            return this;
        }

        public string PriceFormatted => _price.ToString("C", CultureInfo.CurrentCulture);

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
