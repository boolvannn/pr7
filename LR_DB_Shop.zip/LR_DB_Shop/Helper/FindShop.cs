﻿using LR_DB_Shop.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR_DB_Shop.Helper
{
    public class FindShop
    {
        int id;
        public FindShop(int id)
        {
            this.id = id;
        }
        public bool ShopPredicate(Shop shop)
        {
            return shop.Id == id;
        }
    }
}
