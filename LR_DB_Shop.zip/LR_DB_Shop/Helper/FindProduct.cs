﻿using LR_DB_Shop.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR_DB_Shop.Helper
{
    public class FindProduct
    {
        int id;
        public FindProduct(int id)
        {
            this.id = id;
        }
        public bool ProductPredicate(Product product)
        {
            return product.Id == id;
        }
    }
}
