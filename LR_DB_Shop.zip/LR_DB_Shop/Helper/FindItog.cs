﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LR_DB_Shop.Model;

namespace LR_DB_Shop.Helper
{
    public class FindItog
    {
        private int id;

        public FindItog(int id)
        {
            this.id = id;
        }

        public bool ItogPredicate(Itog itog)
        {
            return itog.Id == id;
        }
    }
}
