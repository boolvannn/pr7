﻿using LR_DB_Shop.ViewModel;
using System.Windows;

namespace LR_DB_Shop.View
{
    public partial class WindowProduct : Window
    {
        public WindowProduct()
        {
            InitializeComponent();
            DataContext = new ProductViewModel();
        }
    }
}
