﻿using LR_DB_Shop.Model;
using System;
using System.Windows;

namespace LR_DB_Shop.View
{ 
    public partial class WindowNewTrading : Window
    {
        public WindowNewTrading()
        {
            InitializeComponent();
        }

        private void BtSave_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateInputs())
            {
                DialogResult = true;
                Close();
            }
        }

        private void BtCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(TbPrice.Text) ||
                !decimal.TryParse(TbPrice.Text, out var price) ||
                price <= 0)
            {
                MessageBox.Show("Введите корректную цену!", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(TbCount.Text) ||
                !int.TryParse(TbCount.Text, out var count) ||
                count <= 0)
            {
                MessageBox.Show("Введите корректное количество!", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            if (CbShop.SelectedItem == null)
            {
                MessageBox.Show("Выберите магазин!", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            if (CbProduct.SelectedItem == null)
            {
                MessageBox.Show("Выберите продукт!", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            return true;
        }
    }
}
