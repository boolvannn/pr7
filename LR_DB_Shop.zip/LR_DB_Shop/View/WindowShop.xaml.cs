﻿using LR_DB_Shop.ViewModel;
using System.Windows;


namespace LR_DB_Shop.View
{
    public partial class WindowShop : Window
    {
        public WindowShop()
        {
            InitializeComponent();
            DataContext = new ShopViewModel();
        }

    }
}
