﻿using LR_DB_Shop.Model;
using LR_DB_Shop.ViewModel;
using System.Collections.ObjectModel;
using System.Windows;

namespace LR_DB_Shop.View
{
    public partial class WindowTrading : Window
    {
        private readonly ItogViewModel _itogVM;
        private ObservableCollection<ItogDpo> _itogsDpo = new ObservableCollection<ItogDpo>();
        public WindowTrading()
        {
            InitializeComponent();
            _itogVM = new ItogViewModel();
            lvTrading.ItemsSource = _itogsDpo;
        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            _itogsDpo.Clear();
            _itogVM.LoadItogs();
            _itogVM.LoadShops();
            _itogVM.LoadProducts();

            foreach (var itog in _itogVM.ListItog)
            {
                var itogDpo = new ItogDpo().CopyFromItog(itog);

                var shop = _itogVM.ListShop.FirstOrDefault(r => r.Id == itog.ShopId);
                itogDpo.ShopName = shop?.NameShop ?? "Не указано";

                var product = _itogVM.ListProduct.FirstOrDefault(r => r.Id == itog.ProductId);
                itogDpo.ProductName = product?.NameProduct ?? "Не указано";

                _itogsDpo.Add(itogDpo);
            }
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)  //trip = itog, flight = trading, punktnaznachenia = shop, transport = product
        {
            var wnTrading = new WindowNewTrading
            {
                Title = "Новая торговля",
                Owner = this
            };

            ItogDpo itog = new ItogDpo
            {
                Id = _itogVM.GetMaxId() + 1,
            };

            wnTrading.CbProduct.ItemsSource = _itogVM.ListProduct;
            wnTrading.CbShop.ItemsSource = _itogVM.ListShop;
            wnTrading.DataContext = itog;

            if (wnTrading.ShowDialog() == true)
            {
                Product selectedProduct = (Product)wnTrading.CbProduct.SelectedItem;
                Shop selectedShop = (Shop)wnTrading.CbShop.SelectedItem;

                if (selectedProduct != null && selectedShop != null)
                {
                    itog.ProductName = selectedProduct.NameProduct;
                    itog.ProductId = selectedProduct.Id;
                    itog.ShopName = selectedShop.NameShop;
                    itog.ShopId = selectedShop.Id;

                    Itog newItog = new Itog().CopyFromItogDpo(itog);
                    _itogVM.AddItog(newItog);
                    LoadData();
                }
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            ItogDpo perDPO = (ItogDpo)lvTrading.SelectedItem;
            if (perDPO != null)
            {
                var editWindow = new WindowNewTrading
                {
                    Title = "Редактирование данных",
                    Owner = this,
                    DataContext = perDPO.ShallowCopy()

                };

                editWindow.CbProduct.ItemsSource = _itogVM.ListProduct;
                editWindow.CbShop.ItemsSource = _itogVM.ListShop;
                if (editWindow.ShowDialog() == true)
                {
                    var editedDpo = (ItogDpo)editWindow.DataContext;
                    perDPO.CopyFromItogDpo(editedDpo);

                    var updatedItog = new Itog().CopyFromItogDpo(perDPO);
                    _itogVM.UpdateItog(updatedItog);
                    LoadData();
                }
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            ItogDpo itog = (ItogDpo)lvTrading.SelectedItem;
            if (itog != null)
            {
                MessageBoxResult result = MessageBox.Show(
                    $"Удалить {itog.ProductName} {itog.ShopName}?",
                    "Подтверждение",
                    MessageBoxButton.YesNo);

                if (result == MessageBoxResult.Yes)
                {
                    _itogVM.RemoveItog(itog.Id);
                    LoadData();
                }
            }
        }
    }
}
