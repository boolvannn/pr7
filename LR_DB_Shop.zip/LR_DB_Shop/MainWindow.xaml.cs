﻿using System.Windows;
using LR_DB_Shop.View;

namespace LR_DB_Shop
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Product_click(object sender, RoutedEventArgs e)
        {
            var window = new WindowProduct();
            window.Show();
        }

        private void Itog_click(object sender, RoutedEventArgs e)
        {
            var window = new WindowTrading();
            window.Show();
        }

        private void Shop_click(object sender, RoutedEventArgs e)
        {
            var window = new WindowShop();
            window.Show();
        }
    }
}