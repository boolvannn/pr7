﻿using System;
using System.Collections.Generic;

namespace pr7;

public partial class Product
{
    public int IdProduct { get; set; }

    public string NameProduct { get; set; } = null!;

    public virtual ICollection<Itog> Itogs { get; set; } = new List<Itog>();
}
