﻿using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr7
{
    public partial class MainWindow : Window
    {
        private Shop2Context dbProduct = new Shop2Context(); // Контекст для работы с базой данных

        public MainWindow()
        {
            InitializeComponent();

            // Загружаем данные для фильтрации (список магазинов)
            CmbFiltr.ItemsSource = dbProduct.Shops.ToList();
            CmbFiltr.SelectedValuePath = "IdShop";
            CmbFiltr.DisplayMemberPath = "NameShop";
            LoadData(); // Загружаем все данные при старте приложения
        }

        // Метод для загрузки всех данных в DataGrid
        public void LoadData()
        {
            var itogs = dbProduct.Itogs
                .Include(i => i.IdProductNavigation)  // Загружаем данные о продукте
                .Include(i => i.IdShopNavigation)     // Загружаем данные о магазине
                .ToList();

            DtgProduct.ItemsSource = itogs;  // Привязываем данные к DataGrid
        }

        // Обработчик кнопки поиска
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (TxtSearch.Text == "")
            {
                var itogs = dbProduct.Itogs
                    .Include(i => i.IdProductNavigation)
                    .Include(i => i.IdShopNavigation)
                    .ToList();
                DtgProduct.ItemsSource = itogs;
            }
            else
            {
                var itogs = dbProduct.Itogs
                    .Include(i => i.IdProductNavigation)
                    .Include(i => i.IdShopNavigation)
                    .Where(i => i.IdProductNavigation.NameProduct.Contains(TxtSearch.Text))
                    .ToList();
                DtgProduct.ItemsSource = itogs;

                // Если товаров не найдено
                if (itogs.Count == 0)
                {
                    MessageBox.Show("Такого товара нет");
                }
            }
        }

        // Обработчик кнопки сортировки по возрастанию
        private void BtnSortUp_Click(object sender, RoutedEventArgs e)
        {
            var itogs = dbProduct.Itogs
                .Include(i => i.IdProductNavigation)
                .Include(i => i.IdShopNavigation)
                .OrderBy(i => i.Price)
                .ToList();
            DtgProduct.ItemsSource = itogs;
        }

        // Обработчик кнопки сортировки по убыванию
        private void BtnSortDown_Click(object sender, RoutedEventArgs e)
        {
            var itogs = dbProduct.Itogs
                .Include(i => i.IdProductNavigation)
                .Include(i => i.IdShopNavigation)
                .OrderByDescending(i => i.Price)
                .ToList();
            DtgProduct.ItemsSource = itogs;
        }

        // Обработчик изменения выбора в ComboBox для фильтрации по магазину
        private void CmbFiltr_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedValue != null)
            {
                int idShop = int.Parse(CmbFiltr.SelectedValue.ToString());
                var itogs = dbProduct.Itogs
                    .Include(i => i.IdProductNavigation)
                    .Include(i => i.IdShopNavigation)
                    .Where(i => i.IdShop == idShop)
                    .ToList();
                DtgProduct.ItemsSource = itogs;
            }
        }

        private void BtnAvgPrice_Click(object sender, RoutedEventArgs e)
        {
            double avgPrice = Math.Round(dbProduct.Itogs.Average(i => i.Price), 2);
            TxbAvgPrice.Text = avgPrice.ToString();
        }

        private void BtnMinPrice_Click(object sender, RoutedEventArgs e)
        {
            double minPrice = dbProduct.Itogs.Min(i => i.Price);
            TxbMinPrice.Text = minPrice.ToString();
        }

        private void BtnMaxPrice_Click(object sender, RoutedEventArgs e)
        {
            double maxPrice = dbProduct.Itogs.Max(i => i.Price);
            TxbMaxPrice.Text = maxPrice.ToString();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (DtgProduct.SelectedItem is Itog selectedItog)
            {
                var result = MessageBox.Show("Вы действительно хотите удалить эту запись?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    dbProduct.Itogs.Remove(selectedItog);
                    dbProduct.SaveChanges();
                    LoadData(); // Обновление таблицы
                    MessageBox.Show("Запись успешно удалена.");
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления.");
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (DtgProduct.SelectedItem is Itog selectedItog)
            {
                // Простое окно ввода 
                string newPriceStr = Microsoft.VisualBasic.Interaction.InputBox("Введите новую цену:", "Редактирование", selectedItog.Price.ToString());
                string newCountStr = Microsoft.VisualBasic.Interaction.InputBox("Введите новое количество:", "Редактирование", selectedItog.Count.ToString());

                if (double.TryParse(newPriceStr, out double newPrice) && int.TryParse(newCountStr, out int newCount))
                {
                    selectedItog.Price = newPrice;
                    selectedItog.Count = newCount;

                    dbProduct.Itogs.Update(selectedItog);
                    dbProduct.SaveChanges();
                    LoadData(); // Обновление таблицы
                    MessageBox.Show("Запись успешно обновлена.");
                }
                else
                {
                    MessageBox.Show("Неверный формат данных.");
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для редактирования.");
            }
        }
    }
}