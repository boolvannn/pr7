﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace pr7;

public partial class Shop2Context : DbContext
{
    public Shop2Context()
    {
    }

    public Shop2Context(DbContextOptions<Shop2Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Itog> Itogs { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<Shop> Shops { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlite("Data Source=D:\\\\\\\\shop2.db");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Itog>(entity =>
        {
            entity.HasKey(e => e.IdItog);

            entity.ToTable("itog");

            entity.HasIndex(e => e.IdItog, "IX_itog_id_itog").IsUnique();

            entity.Property(e => e.IdItog).HasColumnName("id_itog");
            entity.Property(e => e.Count).HasColumnName("count");
            entity.Property(e => e.IdProduct).HasColumnName("id_product");
            entity.Property(e => e.IdShop).HasColumnName("id_shop");
            entity.Property(e => e.Price).HasColumnName("price");

            entity.HasOne(d => d.IdProductNavigation).WithMany(p => p.Itogs).HasForeignKey(d => d.IdProduct);

            entity.HasOne(d => d.IdShopNavigation).WithMany(p => p.Itogs).HasForeignKey(d => d.IdShop);
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.IdProduct);

            entity.ToTable("product");

            entity.HasIndex(e => e.IdProduct, "IX_product_id_product").IsUnique();

            entity.HasIndex(e => e.NameProduct, "IX_product_name_product").IsUnique();

            entity.Property(e => e.IdProduct).HasColumnName("id_product");
            entity.Property(e => e.NameProduct)
                .HasColumnType("TEXT (30)")
                .HasColumnName("name_product");
        });

        modelBuilder.Entity<Shop>(entity =>
        {
            entity.HasKey(e => e.IdShop);

            entity.ToTable("shop");

            entity.HasIndex(e => e.IdShop, "IX_shop_id_shop").IsUnique();

            entity.HasIndex(e => e.NameShop, "IX_shop_name_shop").IsUnique();

            entity.Property(e => e.IdShop).HasColumnName("id_shop");
            entity.Property(e => e.NameShop)
                .HasColumnType("TEXT (50)")
                .HasColumnName("name_shop");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
