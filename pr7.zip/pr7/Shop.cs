﻿using System;
using System.Collections.Generic;

namespace pr7;

public partial class Shop
{
    public int IdShop { get; set; }

    public string NameShop { get; set; } = null!;

    public virtual ICollection<Itog> Itogs { get; set; } = new List<Itog>();
}
